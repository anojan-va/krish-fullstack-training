package com.lp.salesmanager.reposiotry;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.annotation.EnableMBeanExport;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.lp.salesmanager.model.Employee;

@Repository
public class HibernateEmployeeRepositoryImpl implements EmployeeRepository {
	
	@Override
	public List<Employee> getAllEmployee(){
		List<Employee> employees = new ArrayList<>();
		
		Employee employee = new Employee();
		
		employee.setEmployeeName("Anojan");
		employee.setEmployeeAddress("Srilanka");
		employees.add(employee);
		
		return employees;
	}

}
