package com.lp.salesmanager.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.lp.salesmanager.model.Employee;
import com.lp.salesmanager.reposiotry.EmployeeRepository;
import com.lp.salesmanager.reposiotry.HibernateEmployeeRepositoryImpl;

@Service("employeeService")
public class EmployeeServiceImpl implements EmployeeService {
	
	@Autowired
	EmployeeRepository employeeRepository;
	
	public EmployeeServiceImpl() {
		System.out.println("Default counstructor execution");
	}
	
	
	
	public EmployeeServiceImpl(EmployeeRepository emploRepository) {
		System.out.println("Overloaded counstructor execution");
		this.employeeRepository=emploRepository;
	}
	
	public EmployeeRepository getEmployeeRepository() {
		return employeeRepository;
	}
	
	
	public void setEmployeeRepository(EmployeeRepository emploRepository) {
		
		this.employeeRepository=emploRepository;
	}

	public List<Employee> getAllEmployees(){
		
		return employeeRepository.getAllEmployee();
		
	}
}
