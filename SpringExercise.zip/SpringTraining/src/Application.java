import java.util.List;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.lp.salesmanager.model.Employee;
import com.lp.salesmanager.service.EmployeeService;


public class Application {
	public static void main(String args[]) {
		
		@SuppressWarnings("resource")
		ApplicationContext applicationContex = new ClassPathXmlApplicationContext("applicationContext.xml");
			
			EmployeeService employeeService = applicationContex.getBean("employeeService",EmployeeService.class);
			List<Employee> employees = employeeService.getAllEmployees();
			
			for(Employee employee:employees) {
				System.out.println(employee.getEmployeeName()+" at "+employee.getEmployeeAddress());
			}
		
		
		
	}

}
