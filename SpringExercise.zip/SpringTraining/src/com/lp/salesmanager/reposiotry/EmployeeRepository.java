package com.lp.salesmanager.reposiotry;

import java.util.List;

import com.lp.salesmanager.model.Employee;

public interface EmployeeRepository {

	List<Employee> getAllEmployee();

}