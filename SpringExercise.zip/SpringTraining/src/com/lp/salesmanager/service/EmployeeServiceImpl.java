package com.lp.salesmanager.service;

import java.util.List;

import com.lp.salesmanager.model.Employee;
import com.lp.salesmanager.reposiotry.EmployeeRepository;
import com.lp.salesmanager.reposiotry.HibernateEmployeeRepositoryImpl;

public class EmployeeServiceImpl implements EmployeeService {
	
	private EmployeeRepository employeeRepository;
	
	public EmployeeServiceImpl(EmployeeRepository emploRepository) {
		this.employeeRepository=emploRepository;
	}
	
	public void setEmployeeRepository(EmployeeRepository emploRepository) {
		
		this.employeeRepository=emploRepository;
	}

	public List<Employee> getAllEmployees(){
		
		return employeeRepository.getAllEmployee();
		
	}
}
