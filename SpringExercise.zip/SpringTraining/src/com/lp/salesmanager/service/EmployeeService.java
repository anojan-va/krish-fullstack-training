package com.lp.salesmanager.service;

import java.util.List;

import com.lp.salesmanager.model.Employee;

public interface EmployeeService {
	
	List<Employee> getAllEmployees();

}