package com.lp.salesmanager.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.lp.salesmanager.model.Employee;
import com.lp.salesmanager.reposiotry.EmployeeRepository;
import com.lp.salesmanager.reposiotry.HibernateEmployeeRepositoryImpl;

public class EmployeeServiceImpl implements EmployeeService {
	
	@Autowired
	EmployeeRepository employeeRepository;
	
	
	public EmployeeServiceImpl(EmployeeRepository emploRepository) {
		System.out.println("Overloaded counstructor execution");
		this.employeeRepository=emploRepository;
	}
	
	public EmployeeServiceImpl() {
		System.out.println("default counstructor execution");
		
	}
	
	public EmployeeRepository getEmployeeRepository() {
		return employeeRepository;
	}
	
	@Autowired
	public void setEmployeeRepository(EmployeeRepository emploRepository) {
		System.out.println("Setter execution");
		this.employeeRepository=emploRepository;
	}

	public List<Employee> getAllEmployees(){
		
		return employeeRepository.getAllEmployee();
		
	}
}
