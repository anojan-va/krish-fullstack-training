import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.lp.salesmanager.reposiotry.EmployeeRepository;
import com.lp.salesmanager.reposiotry.HibernateEmployeeRepositoryImpl;
import com.lp.salesmanager.service.EmployeeService;
import com.lp.salesmanager.service.EmployeeServiceImpl;

@Configuration
@ComponentScan("com.lp")
public class ApplicationConfiguration {
	@Bean(name="employeeService")
	public EmployeeService getEmployeeService() {
		//return new EmployeeServiceImpl();
		//EmployeeServiceImpl employeeService = new EmployeeServiceImpl(getEmployeeRepository());
		EmployeeServiceImpl employeeService = new EmployeeServiceImpl();
		//employeeService.setEmployeeRepository(getEmployeeRepository());
		return employeeService;
	}
	
	/*
	@Bean(name="employeeRepository")
	public EmployeeRepository getEmployeeRepository() {
		return new HibernateEmployeeRepositoryImpl();
	}
	*/
	

}
