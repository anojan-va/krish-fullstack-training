package com.lp.rentacar.service;

import com.lp.rentacar.model.Student;

public interface StudentService {

	Student save(Student student);
}
