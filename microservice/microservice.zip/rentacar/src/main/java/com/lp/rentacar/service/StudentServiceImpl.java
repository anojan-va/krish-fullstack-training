package com.lp.rentacar.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lp.rentacar.model.Student;
import com.lp.rentacar.repository.StudentRepository;

@Service
public class StudentServiceImpl implements StudentService {

	@Autowired
	StudentRepository studentRepository; 
	
	@Override
	public Student save(Student student) {
		return studentRepository.save(student);
		
	}
	

}
