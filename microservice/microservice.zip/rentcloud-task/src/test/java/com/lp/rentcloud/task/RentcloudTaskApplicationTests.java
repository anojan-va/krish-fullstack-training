package com.lp.rentcloud.task;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RentcloudTaskApplicationTests {

	@Test
	void contextLoads() {
	}

}
