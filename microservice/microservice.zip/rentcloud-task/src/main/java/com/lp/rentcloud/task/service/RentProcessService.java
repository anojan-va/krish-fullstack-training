package com.lp.rentcloud.task.service;

public interface RentProcessService {
    boolean validateDL(String dlNumber);
}
