package com.lp.profileservice.service;

import java.util.List;

import com.lp.rentcloud.common.model.Customer;

public interface CustomerService {
	
	Customer save(Customer customer);
	Customer fetchById(int profileId);

    List<Customer> fetchAllProfiles();

}
