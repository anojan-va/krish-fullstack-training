package rentacar;

public class VehcleType {

	public static final VehcleType CAR = null;

}
