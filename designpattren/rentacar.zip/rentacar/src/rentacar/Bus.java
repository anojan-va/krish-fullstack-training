package rentacar;

public class Bus extends Vechile {
	
	private int numberOfSeats;
	

	public int getNumberOfSeats() {
		return numberOfSeats;
	}

	public void setNumberOfSeats(int numberOfSeats) {
		this.numberOfSeats = numberOfSeats;
	}
	
	@Override
	public String toString(){
		return "Bus{"+"nuberofseats="+numberOfSeats+'}';
	}
	

}
