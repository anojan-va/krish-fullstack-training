package rentacar;

public class App {
	public static void main(String args[]) {
		
		Registry registry = new Registry();
		Car car =(Car)registry.getVehicle(VehcleType.CAR);
		System.out.print(car);
		car.setType("lux");
		
		
		System.out.println(car);
		Car car1=(Car)registry.getVehicle(VehcleType.CAR);
		System.out.println(car1);
	}
}
