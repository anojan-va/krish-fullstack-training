package rentacar;

import java.util.HashMap;
import java.util.Map;

public class Registry {
	private Map<VehcleType,Vechile> vehiles = new HashMap<>();

	public Registry() {
		this.initialize();
	}
	
	public Vechile getVehicle(VehcleType vechiletype) {
		Vechile vechile =null;
		try {
			vechile= (Vechile) vehiles.get(vechiletype).clone();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return vechile;
	}
	
	private void initialize() {
		Car car = new Car();
		car.setEngineCapacity(2000);
		car.setType("mini");
		car.setFuelType("Gasoline");
		
		Bus bus = new Bus();
		bus.setNumberOfSeats(32);
		bus.setEngineCapacity(2000);
		bus.setFuelType("Diseal");
	}

}
